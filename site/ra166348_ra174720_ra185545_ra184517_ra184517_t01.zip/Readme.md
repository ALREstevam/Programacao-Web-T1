# Grupo

* Andr� L. R. Estevam 166348
* Huanna Raquel Do Nascimento 174720
* Pedro Artico Rodrigues 185545
* Mayara Naomi Fustaino Ramos 184517
* Karen Esbaile Malzoni Rodrigues 177493